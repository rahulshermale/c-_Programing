﻿using System;
using AssignmentNo_01_Q3;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentNo_01_Q3
{
    internal class Program
    {
        public static int Main(string[] args)
        {
            Console.WriteLine("Hello,World !");
            return 0;
        }

        Program.Main(new string[] {});
    }
}
