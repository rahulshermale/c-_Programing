﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte b1 = 10;
            byte b2 = 5;
           byte c= (byte)(b1 + b2);
            Console.WriteLine(c);
        }
    }
}
