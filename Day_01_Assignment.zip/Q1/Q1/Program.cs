﻿namespace Q1
{
    internal class Program
    {
        public static int square(int x) {
            return x * x;

        }
        public static int cube(int y) {
        return y * y*y;
        }
      //  public static double pow(double x, double exel)
      //  {
       //     return Math.Pow(x,exel);
        //}
    }
}
