﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1Demo03
{
    internal class myclass
    {
        static void Main(string[] args)
        {
            int a = 55;
            Console.WriteLine(a );
            Console.ReadLine();
        }
    }
}
