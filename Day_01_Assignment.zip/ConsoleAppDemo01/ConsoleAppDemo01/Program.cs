﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDemo01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 55;
            Console.WriteLine("Hello word ! ");
            Console.ReadLine();
            Console.WriteLine(a);
        }
    }
}
