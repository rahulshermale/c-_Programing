﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_01
{
    internal class Class1
    {
        public static int square(int x)
        {
            return x * x;

        }
        public static int cube(int y)
        {
            return y * y * y;
        }
        public static double pow(double x, double exel)
        {
            return Math.Pow(x, exel);
        }
    }
}
