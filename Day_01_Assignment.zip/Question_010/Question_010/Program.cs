﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_010
{
    internal class Program
    {
        static void Main(string[] args)
        {

            char c1 = '9';
            char c2 = '9';
            char c = Convert.ToChar(c1+c2);
            Console.WriteLine(c);

        }
    }
}
